# INTERVIEW_WEAKNESSES.md

One entry per struggle. Never delete; mark resolved once re-tested.

## Template

### W-000 — <short title>
- **Phase / level:**
- **Question:**
- **My answer:**
- **Correct reasoning:**
- **Conceptual gap:**
- **Follow-up exercise:**
- **Re-tested:** ☐ (date, result)

---
_(no entries yet)_
