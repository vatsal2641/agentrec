# LEARNING_NOTES.md: AgentRec from first principles

This is the course. Read it in order. Every section follows the same pattern:
**intuition → toy numbers → maths → where it lives in the repo → quiz**. Quiz answers are hidden in
`<details>` blocks. Write your own answer down first, then check it.

The rule for moving on: if you can't answer a quiz question without looking, go back over that
section. Log the miss in `INTERVIEW_WEAKNESSES.md` and do the linked exercise in `exercises/`.

Contents
1. Recommender foundations (the 20 concepts)
2. Data: splits, leakage, implicit feedback
3. Baselines: popularity, content, item-kNN, matrix factorisation
4. Retrieval: embeddings, two-tower, ANN
5. Ranking: losses and metrics
6. Bandits: from zero to LinUCB / Thompson sampling
7. Feedback loops
8. LLMs in recommendation
9. Agents
10. Memory
11. Putting it together (system design)

---

## 1. Recommender foundations

### 1.1 What a recommender is
**Intuition.** There are too many items for anyone to look through. A recommender picks a
short **ordered list** per user, per moment. The output is a *ranking*, not a label.

**Toy example.** There are 4 users and 5 movies (· = never rated):

```
      i1  i2  i3  i4  i5
A      5   3   ·   1   ·
B      4   ·   5   ·   ·
C      ·   4   4   ·   2
D      5   ·   ·   ·   ·
```
9 of 20 cells are filled, so density is 45%. MovieLens-1M has 1,000,209 ratings over 6,040 users × 3,706 rated movies (movies.dat lists
3,883), a density of about 4.5%. Production systems are around 0.01% dense.

**Maths.** R ∈ ℝ^{|U|×|I|}, and Ω is the set of observed (u,i) pairs.
Rating prediction learns f with f(u,i) ≈ r_ui on Ω. Top-K recommendation outputs L_u = the top-K
items of {f(u,i) : i ∉ seen(u)}.

**In the repo.** `data/dataset.py` builds R as a sparse CSR matrix (`Dataset.matrix`). Every model
implements `score(users) → (n_users, n_items)` in `models/base.py`.

### 1.2 Why this is not ordinary classification
1. **Missing is not negative (MNAR).** A blank means "never saw it" far more often than "dislikes it".
   People watch what they expect to like and what is shown to them. The synthetic generator builds
   this bias in deliberately: exposure ∝ exp(α·popularity + β·affinity).
2. **The system creates its own training data.** You only get labels for items you showed, so today's
   model decides tomorrow's labels. That loop is §7.
3. **The output is a list from a huge candidate set, and positions matter.** Metrics weight the top of
   the list more heavily (§5).
4. **Time matters.** Tastes drift and new items arrive, so evaluation must respect time (§2).

### 1.3 Explicit vs implicit feedback
- Explicit: ratings, likes. Clear signal, but rare.
- Implicit: clicks, watches, dwell time. Plentiful, but noisy, positive-only, and position-biased.

In the repo, a rating ≥ 4 counts as a positive (`pos_threshold`). A rating ≤ 3 means "seen but not
liked". It is excluded from the positives but still masked at evaluation time.

### 1.4 Rating prediction vs top-K
Rating prediction (the Netflix Prize, RMSE) scores the *observed* cells. But the product question is
"what should we show?", and that requires ranking *unobserved* items. A model with low RMSE can still
rank badly, because it never learned anything about what people choose to watch. We therefore
optimise for, and evaluate, **top-K**.

### 1.5 Candidate generation, ranking, and why there are two stages
- **Retrieval (candidate generation):** a cheap score, pick N ≈ 100–1000 from millions. Recall
  matters most here.
- **Ranking:** an expensive, feature-rich score over those N. Precision at the top matters most here.

**Why not score every item with the ranker?** Back-of-envelope numbers: 10⁷ items × 1 µs per ranker
call = 10 s per request, against a budget of about 100 ms. Retrieval is only possible when the score
factorises as ⟨user_vec, item_vec⟩, because then a nearest-neighbour index can search without
touching every item. E3's "no retrieval" ablation measures this on our data.

### 1.6 Content-based filtering
Build a profile as the mean of the feature vectors of the items a user liked, then score items by
cosine similarity to it.

**Toy example.** The features are [Action, Comedy]. User A liked i1 = [1,0] and i2 = [1,1]. After
normalising, profile ∝ [2,1]/√5.
- A new item [0,1]: cos = 1/√5 ≈ 0.45.
- A new item [1,0]: cos = 2/√5 ≈ 0.89. This one is recommended.

Strength: it can score **new items**. Weaknesses: it is only as good as the metadata, and it keeps
recommending "more of the same".
Code: `models/baselines.py::ContentBased`.

### 1.7 Collaborative filtering
"Users who liked what you liked also liked X." It uses only the interaction matrix.
- Item-kNN: sim(i,j) = |U_i ∩ U_j| / (√|U_i| √|U_j| + shrink), and score(u,i) = Σ_{j∈hist(u)} sim(j,i).

**Toy example.** i1 is liked by {A,B,D}, and i3 by {B,C}. They share 1 user, so
sim = 1/(√3·√2 + 0) ≈ 0.41. The shrink term pulls down similarities that rest on only a few users.
Code: `ItemKNN`.

### 1.8 Matrix factorisation and embeddings
Approximate the score as s(u,i) = p_uᵀq_i + b_i with p, q ∈ ℝ^d, and d ≪ |U|, |I|. Users and items
live in the same space, and a dot product measures agreement.

An **embedding** is just a learned vector like p_u or q_i. With d = 64, the whole catalogue becomes
a 3,883 × 64 matrix (ML-1M's full movies.dat).
Code: `models/mf_bpr.py` (BPR loss, §5).

### 1.9 Two-tower models
A **user tower** f(user features) → z_u and an **item tower** g(item features) → v_i, scored by
s = ⟨z_u, v_i⟩. Matrix factorisation is the special case where both towers are ID lookups. Ours
differs in two ways:
- The user tower reads the user's **recent liked items** instead of a user ID. So a single click
  changes z_u immediately, with no retraining. This is the whole basis of the feedback-adaptation
  story.
- The item tower adds genres, so brand-new items still get a sensible vector.

Code: `models/two_tower.py`. The backprop is written by hand, and the file header derives every step.

### 1.10 Neural recommenders
These are any recommenders whose towers or ranker are neural networks: an MLP in the tower, sequence
models (GRU4Rec, SASRec), or deep ranking models (Wide&Deep, DLRM). Ours is deliberately small: a
residual one-hidden-layer MLP in the user tower. Say exactly that in an interview. Don't inflate it.

### 1.11 Cold start
- **New user:** there's no history. Fall back to (recent) popularity. After a few clicks, the
  history-based tower takes over. E5 measures this.
- **New item:** it has no interactions, so collaborative models can't score it. Content features can
  (the genre part of the item tower, `ContentBased`). `describe()` reports how many test positives
  fall on cold items.

### 1.12 Exploration vs exploitation
If you always show what the model currently believes is best, it never learns about the items it's
wrong about. Exploring means sometimes showing uncertain items to collect information. That costs
some reward now for better decisions later. §6 treats this properly.

### 1.13 Offline vs online
- Offline: evaluate on logged data, which is cheap and safe, but biased toward what the old system
  showed.
- Online: A/B tests on real users, which gives the true answer but is slow and risky.
- Simulators sit in between. They are only as good as their assumptions.

### 1.14 Feedback loops
The model decides what gets shown, what gets shown decides what gets clicked, and clicks train the
next model. If nothing counteracts it, popular items get more popular and the model's blind spots
never get corrected. The remedies are exploration, debiasing (position and propensity), diversity
constraints, and monitoring.

### 1.15 Evaluation (preview; details in §5)
Use full-ranking top-K metrics on a temporal split: Recall, Precision, NDCG, MRR and MAP @K, plus
coverage and popularity bias.

### Quiz 1
1. A classmate fills every blank with 0 and trains an MSE regressor. In the toy matrix, what does the
   model learn about D and i3, and why is that wrong?
2. Rank the toy items by count of ratings and by mean rating. A new item i6 gets a single 5★. Where
   does it land under each ranking? What fix handles this?
3. Give two reasons, one about compute and one about labels, why "a binary classifier on every
   (user, item) pair" is a poor framing.
4. Our user tower has no user-ID embedding. Name one benefit and one cost.

<details><summary>Answers</summary>

1. It learns r(D,i3) ≈ 0, meaning "D hates i3". But D simply never saw i3, and D's one rating
   (i1 = 5★) matches B, who gave i3 5★. Filling blanks with 0 treats exposure as preference, which
   is the MNAR problem.
2. By count: i1 (3), then i2 and i3 (2 each), then i4 and i5 (1 each). By mean: i1 = 4.67,
   i3 = 4.5, i2 = 3.5, i5 = 2, i4 = 1. A new i6 with one 5★ has mean 5.0 and jumps to #1 by mean,
   while it is last by count. One lucky rating shouldn't beat 3 consistent ones. Fixes: a Bayesian
   average / shrinkage, mean = (Σr + m·μ)/(n + m), or a minimum-count threshold.
3. Compute: |U|·|I| pairs per training epoch and per request is intractable, which is why retrieval
   exists. Labels: the negatives aren't real negatives (MNAR), and labels exist only for items that
   were shown (selection bias / feedback loop).
4. Benefit: an instant update after a click, and new users need no retraining. Cost: the model can't
   store user-specific quirks that aren't visible in their recent items, and users with very long
   histories get truncated to L items.
</details>

---

## 2. Data

### 2.1 Temporal splitting and leakage
A random split puts a user's 2003 ratings in train while testing on their 2000 ratings. The model
then "knows the future": the items that became popular later, and the user's later tastes. Metrics
come out inflated, and the ranking of models can flip.

**What we do** (`build_dataset`) is a *global* time split at the 80th and 90th timestamp percentiles.
```
train: t < t_val        val: t_val ≤ t < t_test        test: t ≥ t_test
tuning: fit train → score val       final: refit train+val → score test (hyper-params frozen)
```
Alternatives:
- Per-user leave-last-out. It's common in papers, but because users' timelines overlap, a test item
  for one user can come after training items for another. That is mild leakage, and it doesn't match
  deployment.
- Sliding windows. More realistic, but more expensive.

Subtler leakage checks:
- Popularity features must be computed only from the fit period. The `FeatureBuilder` does this.
- The two-tower training history for a target uses **only earlier items**. This is tested in
  `test_two_tower_history_is_strictly_before_target`.
- The ranker is trained on a *later* window than the stage-1 models (§5.1).
- Any feature built on "all data" leaks. That's why the bandit simulator's proxy truth (a model fit on
  *all* periods) is **never** given to the recommender.

### 2.2 Implicit conversion
A rating ≥ 4 is a positive. The threshold is a modelling choice: 3★ is ambiguous. `frac_positive` in
`data_stats.json` shows the class balance.

### 2.3 Negative sampling
Implicit data has no explicit negatives, so we *sample* them.
- **Uniform** (BPR): easy, but most sampled items are obviously irrelevant.
- **In-batch** (two-tower): the other positives in the batch act as negatives. This is free, but
  popular items get over-sampled, so we subtract log q(item) from the logits (the logQ correction).
- **Hard negatives**: items the model currently ranks high but the user didn't choose. They give more
  signal, but carry a risk of false negatives (the user would have liked them).

### 2.4 IDs, histories, features
- Raw IDs map to contiguous indices over the **whole catalogue**, so items that appear only in test
  still exist and have metadata.
- A history is the time-ordered list of liked items, truncated to the last L.
- Features: genre multi-hot, decade, popularity (all-time and recency-decayed), user activity.

### 2.5 Cold start in the split
`describe()` counts `test_users_cold` (users with **no fit-period ratings at all**) and
`test_positive_pairs_on_cold_items`. The evaluator reports **cold / sparse / warm user** slices.
Careful: the evaluator's "cold" means **no positives** in the fit period, which is a slightly larger
set than `describe()`'s "no ratings at all". A user who only gave 1–3★ ratings is cold for the
models but not for `describe()`. That's why the counts differ (59 vs 63 on the synthetic data).

### Quiz 2
1. Why is "refit on train+val before testing" legitimate, but "choose hyper-parameters by test score"
   not?
2. Global time split vs leave-last-out: construct a concrete leakage example for leave-last-out.
3. Why does in-batch negative sampling need a popularity correction? Which direction is the bias in
   without it?
4. Name a leak that the time split alone does NOT prevent.

<details><summary>Answers</summary>

1. Refitting uses only past data with frozen choices, which is what you'd do in production. Choosing
   by test score turns the test set into a validation set, so the reported number becomes optimistic.
2. User X's last rating is on 2000-05-01, and it's held out for test. User Y rated heavily until
   2003, and all of that is in train. Y's 2001–2003 behaviour, including item popularity trends,
   informs predictions for X's 2000 test item.
3. Popular items show up often as other rows' positives, so they're used as negatives
   disproportionately. The model learns to push popular items **down** too much. Subtracting log q
   removes that sampling frequency from the logits.
4. Features computed on the full dataset (global popularity, a pretrained embedding trained on all
   data, an LLM that has read post-split reviews), and tuning on test.
</details>

---

## 3. Baselines (Phase 2)

For each model: **input → output → training → inference → complexity → strengths → weaknesses →
failure case**.

| model | input | training | inference per user | strengths | weaknesses / failure case |
|---|---|---|---|---|---|
| Popularity | counts | O(\|R\|) | O(\|I\|) (same list for all) | very strong on sparse data, no cold start | no personalisation; niche users get mainstream lists |
| Recent popularity | counts + time | O(\|R\|) | O(\|I\|) | captures trends under a temporal split | same as above |
| Content (genres+decade) | metadata + likes | O(\|R\|·f) | O(\|I\|·f) | scores new items | over-specialisation; blind to quality |
| Item-kNN | interaction matrix | O(Σ_u \|h_u\|²) for XᵀX | O(\|h_u\|·k) | strong, explainable | quadratic similarity build; can't score cold items |
| BPR-MF | positives | O(epochs·\|R\|·d) | O(\|I\|·d) or ANN | compact, ANN-friendly | ID-only: can't score cold items; sensitive to reg/lr |
| Two-tower | history + genres | O(epochs·\|R\|·(Ld + d²)) | tower O(Ld+d²) + ANN | instant update, partial cold start | more hyper-parameters; ours is tiny, not SOTA |

**Why we eventually need more than these.** They are all *static*. They don't learn from their own
recommendations, don't explore, can't take instructions ("no horror"), and can't explain themselves
in a user's terms.

### Quiz 3
1. Why is popularity hard to beat on sparse data?
2. What is the cost of item-kNN's similarity step at 10M items? How would you approximate it?
3. Why does BPR need negative sampling but item-kNN doesn't?

<details><summary>Answers</summary>

1. Most users are sparse and most interactions land on head items, so "what everyone likes" is a
   strong prior. Personalised models only win once they have enough signal per user.
2. A dense XᵀX has 10¹⁴ entries, which is impossible. In practice you'd use sparse co-occurrence with
   sampling or thresholding, min-hash / LSH, or embedding-based ANN over item vectors.
3. BPR optimises an *ordering* between observed and unobserved items, so it needs unobserved samples.
   Item-kNN is a closed-form similarity computed from co-occurrence counts, with nothing to optimise.
</details>

---

## 4. Retrieval (Phase 4)

### 4.1 The two-tower loss (in-batch softmax)
For a batch of B (history, positive) pairs, compute z_b = user tower and v_c = item tower, both
L2-normalised:
```
S_bc = cos(z_b, v_c)/τ − log q_c ,   L = −(1/B) Σ_b log softmax(S_b)_b
```
**Toy example with B = 2 and τ = 1.** cos(z₁,v₁) = 0.9, cos(z₁,v₂) = 0.5, and logq is ignored.
Then softmax_1 = e^0.9/(e^0.9+e^0.5) = 0.599, so the loss for row 1 is −ln 0.599 = 0.51.
The gradient pushes z₁ toward v₁ and away from v₂, in proportion to (p − y).
The temperature τ sharpens the softmax: a smaller τ puts more weight on hard negatives.

**Backprop.** This is written out by hand at the top of `two_tower.py`, and `test_two_tower_gradients_match_finite_differences`
checks every parameter to a relative error below 1e-4. Be able to derive the normalisation backward
pass: dx = (dx̂ − x̂(x̂·dx̂))/‖x‖.

### 4.2 Approximate nearest neighbours
- **Exact search:** q·Vᵀ costs O(|I|·d). At 3.7k items it takes microseconds. At 10M items it doesn't
  fit the budget (E2 extrapolates from the measured ns/item).
- **IVF** (inverted file): k-means the item vectors into C lists. At query time, score the C
  centroids, then scan only the `n_probe` nearest lists. Cost is O(C·d + (n_probe/C)·|I|·d). The
  trade-off is lower recall. `retrieval/index.py` implements it in about 40 lines, and E2 reports ANN
  recall against latency for each `n_probe`.
- Others: HNSW (graph-based; the best recall/latency, but more memory) and product quantisation
  (compresses vectors). FAISS and ScaNN are production libraries. Our `FaissIndex` wrapper is
  optional.

### 4.3 Retrieval metrics
Recall@N of the candidate set is the ceiling for the whole system. The ranker can't recover an item
that retrieval dropped. Look at candidate diversity too: E2 compares embedding-only, popularity-only
and union candidates.

### Quiz 4
1. Answer "why not score every item?" with numbers for 10M items.
2. What happens to IVF recall when n_probe = C? When n_probe = 1?
3. Why must the retrieval score be a dot product (or another metric) in order to use ANN?
4. What does the temperature τ do? What goes wrong if τ is far too small?

<details><summary>Answers</summary>

1. Take the E2 measurement (ns per dot product) × 10⁷. With a real ranker at about 1 µs per item,
   that's around 10 s. Retrieval brings the ranker's work down to N ≈ 500 items, about 0.5 ms.
2. With n_probe = C it's exact search (recall 1), but no faster. With n_probe = 1 it's fastest, but
   misses neighbours that sit in adjacent clusters.
3. ANN structures index points in a fixed vector space and rely on geometry. A score with cross
   features, f(u,i) with interactions, can't be precomputed per item.
4. It scales the logits. A tiny τ turns the softmax into almost a hard max: the gradients concentrate
   on the hardest negative, training becomes unstable, and it overfits to false negatives.
</details>

---

## 5. Ranking (Phase 5)

### 5.1 Why train the ranker on a later window
Stage-1 scores computed on stage-1's own training data are memorised, so they're overconfident. A
ranker trained on them learns "trust retrieval score". We fit stage 1 on **train**, generate
candidates and labels for **val**, train the ranker there, and test on **test** with stage 1 refit on
train+val.

### 5.2 Losses
- **Pointwise**: predict P(relevant | features) with binary cross-entropy:
  L = −[y log p + (1−y) log(1−p)]. Simple and calibrated, but it ignores that only the *order within
  a user's list* matters.
- **Pairwise**: for a positive i and a negative j of the same user,
  L = −log σ(s_i − s_j) (this is RankNet, and the same form as BPR). It optimises order directly.
  Our implementation trains logistic regression on feature *differences*.
- **Listwise**: a loss over the whole list: softmax cross-entropy, ListNet, or LambdaRank, which
  weights pairs by their NDCG change. It's the closest to the final metric, but more complex.
- **GBDT**: gradient-boosted trees. Non-linear feature interactions, no need for feature scaling, and
  the industry default for tabular ranking features.

Choice in the repo: we train all of them. The chosen ranker is whichever wins on **held-out
validation users**, never on test. See E3 for the result and for whether the ranker beats retrieval
order at all.

### 5.3 Metrics, with a worked example
Take ranked = [3, 1, 7, 5] and relevant = {1, 5, 9}, so hits are at positions 2 and 4.
- Precision@4 = 2/4 = 0.5. Recall@4 = 2/3.
- MRR = 1/2 (the first hit is at position 2).
- DCG@4 = 1/log₂3 + 1/log₂5 = 0.631 + 0.431 = 1.062. IDCG = 1 + 0.631 + 0.5 = 2.131.
  So NDCG = 0.498.
- AP@4 = (P@2 + P@4)/min(4,3) = (0.5 + 0.5)/3 = 0.333.

These numbers are exactly `tests/test_metrics.py`.

When each metric fits:
- Recall@K: coverage of what the user will like. The key metric for retrieval.
- Precision@K: the fraction of the slate that's good.
- NDCG: position-aware and handles multiple positives. The main ranking metric.
- MRR: when the first good item is what matters.
- MAP: precision averaged at every hit.

**Full ranking vs sampled.** Many papers rank 1 positive against 100 sampled negatives. This inflates
scores and can reorder models (Krichene & Rendle, KDD 2020). We rank the full catalogue.

### Quiz 5
1. Compute NDCG@3 for ranked = [a, b, c] and relevant = {c}.
2. Why can pointwise loss be fine for NDCG even though it ignores order?
3. Your ranker's validation NDCG beats retrieval order by 20%, but test shows no gain. Give three
   possible causes.

<details><summary>Answers</summary>

1. DCG = 1/log₂4 = 0.5. IDCG = 1. So NDCG = 0.5.
2. If the predicted probabilities are monotone in true relevance, sorting by them gives the right
   order. Pointwise is a consistent surrogate given enough capacity and data.
3. The ranker was selected or trained on the same users it was measured on (overfitting); the feature
   distribution shifted between the val and test windows, because stage 1 was refit; there are too
   few positives inside the candidates, so the ranker learns noise; or a feature leaks in val but not
   in test.
</details>

---

## 6. Bandits (Phase 6)

### 6.1 Multi-armed bandit
There are K slot machines ("arms"). Arm a pays 1 with unknown probability μ_a. Each round you pull
one arm and see only *its* reward. That partial view is called bandit feedback.

**Regret** after T rounds is R_T = T·μ* − Σ_t μ_{a_t}. It is the expected reward you lost by not
always pulling the best arm.

**Toy example.** μ = [0.3, 0.5]. If you pull arm 1 for 100 rounds, regret = 100 × 0.2 = 20.

### 6.2 ε-greedy
With probability ε pull a random arm, otherwise pull the arm with the best empirical mean. With a
fixed ε, regret grows **linearly** (≈ ε·T·average gap), because it keeps exploring forever. Decaying
ε helps.

### 6.3 UCB1: optimism in the face of uncertainty
Pull argmax_a μ̂_a + c√(2 ln t / n_a).

**Toy example.** At t = 100, arm A has μ̂ = 0.50 with n = 90, and arm B has μ̂ = 0.40 with n = 10.
- Bonus for A: √(2·ln100/90) = √(9.21/90) = 0.32, so its UCB is 0.82.
- Bonus for B: √(9.21/10) = 0.96, so its UCB is 1.36.

**B gets pulled**, because it's under-explored. As n_B grows, its bonus shrinks. Regret is
O(Σ ln T / gap), which is logarithmic.

### 6.4 Thompson sampling
Keep a posterior Beta(α_a, β_a) per arm and start from Beta(1,1), which is uniform. Each round, sample
θ_a ~ Beta(α_a, β_a) and pull argmax θ_a. After the reward r, update α += r and β += 1−r. This works
because Beta is **conjugate** to Bernoulli: the posterior stays a Beta.

**Toy example.** An arm with 3 successes in 5 pulls has posterior Beta(4, 3), mean 4/7 = 0.57, with
wide spread. An arm with 30 successes in 50 pulls has Beta(31, 21), mean 0.60, with narrow spread.
The first arm still gets sampled high sometimes, so it gets explored in proportion to the
**probability that it is the best arm**.

### 6.5 Contextual bandits
The reward depends on a context x_{t,a} (user × item features): E[r | x] = θᵀx. We keep one θ shared
by all items, which lets it generalise to items never shown before.

**LinUCB** (Li et al., WWW 2010):
```
A = λI + Σ x xᵀ,    b = λθ₀ + Σ r x,    θ̂ = A⁻¹ b
score(x) = θ̂ᵀx + α √(xᵀ A⁻¹ x)
```
The bonus √(xᵀA⁻¹x) is the standard deviation of θ̂ᵀx in direction x. It's large for feature
directions we've rarely seen. A⁻¹ is updated in O(d²) per observation with **Sherman–Morrison**:
A⁻¹ ← A⁻¹ − (A⁻¹x)(A⁻¹x)ᵀ/(1 + xᵀA⁻¹x). This is tested against a direct inverse.

**Linear Thompson sampling:** sample θ̃ ~ N(θ̂, v²A⁻¹) and score θ̃ᵀx.

**Warm start, and where it fails.** We set θ₀ so that the prior *mean* reproduces the offline
ranker's order. For greedy that's a true warm start. For LinUCB it isn't: at t = 0, A = λI, so the
bonus is α‖x‖/√λ. That bonus varies across candidates much more than the small prior term does, so
the first slates are mostly exploration. Measured: at t = 0 LinUCB matched the ranker's top 5 for
only a small minority of users. Increasing λ shrinks the bonus (1/√λ) and makes the prior matter more (it mitigates the problem, but doesn't remove it).
This is one reason the λ = 100 runs in E6 do better. Lesson: a prior mean alone doesn't control
optimism.

### 6.6 How recommendation becomes a contextual bandit (in our code)
- **Context:** x = [1, ranker score, 9 ranking features, √D·(z_u ⊙ v_i), position one-hot], built
  in `bandits/env.py`.
- **Action:** a slate of K = 5 items from the ranker's top N = 50 (each slot gets the next-best UCB
  or TS score).
- **Reward:** a click (plus a rating bonus in the feedback loop). A skip is an explicit
  examined-but-not-clicked.
- **Policy:** the score rule plus the exploration strategy. **Value estimate:** θ̂ᵀx.
  **Uncertainty:** √(xᵀA⁻¹x) or the posterior.

### 6.7 Position bias
A user sees item k with probability e_k (we use e_k = 1/k^0.7). An item at position 5 gets few
clicks even if it's great. Naive learning treats "not clicked" as "bad" and wrongly punishes items
shown low. The fixes:
- Put **position in as a feature** during training. At scoring time, set all position dimensions to 0,
  a neutral reference that is the same for every candidate. The greedy order is then free of
  position effects; the UCB bonus still depends on the position dims' uncertainty.
  This is what we use.
- IPS weighting with known propensities.
- Click models (cascade, PBM).

E4b compares naive, position-feature, and an oracle that knows which items were examined.

### 6.8 Why not just supervised learning?
Supervised learning on logs learns "what users clicked **among what we showed**". It can't learn
about actions it never takes, and its errors reinforce themselves. A bandit **chooses its own data**
to reduce the uncertainty that matters. The cost is some reward spent on exploring.

### 6.9 Offline evaluation of bandits (important)
You can't evaluate a new policy on logs from an old one naively, because rewards for unshown items
are missing. The options:
- (a) Fully observed data (KuaiRec).
- (b) Replay on uniformly random logs (Li et al., WSDM 2011), using only the rounds where the logged
  action equals the policy's action.
- (c) IPS or doubly-robust off-policy estimators, which need the logging propensities.
- (d) A simulator.

We use (d) and label it everywhere.

### 6.10 Assumptions and limitations (say these unprompted in interviews)
- Rewards are linear in the features, and stationary. In reality, tastes drift.
- Rounds are independent. In reality, one recommendation changes the next session.
- Clicks are immediate. In reality, feedback is delayed (see §7).
- A slate is treated as K independent picks, ignoring interactions between the items.
- The simulator's truth is a **model**: exact on synthetic data, a BPR proxy on MovieLens. Bandit
  results show how the policies behave *under these assumptions*, not how real users react.

### Quiz 6
1. Compute the UCB1 scores for μ̂ = (0.6, 0.55), n = (100, 4), t = 104. Which arm is pulled?
2. An arm has 2 successes and 8 failures under a Beta(1,1) prior. What are its posterior and mean?
3. Why does ε-greedy with constant ε have linear regret? Why doesn't UCB?
4. Derive why √(xᵀA⁻¹x) shrinks after repeatedly observing x.
5. The bandit gets rewards only for clicks, and users click position 1 far more. Without correction,
   what does the policy learn?

<details><summary>Answers</summary>

1. ln 104 = 4.644.
   - Arm 1: 0.6 + √(9.29/100) = 0.6 + 0.305 = 0.905.
   - Arm 2: 0.55 + √(9.29/4) = 0.55 + 1.524 = 2.07.

   Arm 2 is pulled.
2. The posterior is Beta(3, 9), with mean 3/12 = 0.25.
3. ε-greedy keeps spending a fixed fraction ε of rounds on random arms forever, so its regret is at
   least ε·T·average gap. UCB's bonus for a bad arm drops below the best arm's value after about
   ln T / gap² pulls, so it stops pulling that arm.
4. After n observations of the same x, A = λI + n·xxᵀ. Sherman–Morrison gives
   xᵀA⁻¹x = (‖x‖²/λ) / (1 + n‖x‖²/λ) = ‖x‖² / (λ + n‖x‖²), which shrinks like 1/n. The width is the
   square root of that, so it shrinks like 1/√n. Directions orthogonal to x are unaffected.
   `test_linucb_width_shrinks_in_observed_directions` checks both facts.
5. It learns that features correlated with being placed high predict clicks, so it keeps reinforcing
   the ranker's top items. Items shown low look bad regardless of quality. That's a self-confirming
   loop.
</details>

---

## 7. Feedback loop (Phase 7)

```
recommend → user interacts → Event rows (impression/click/skip/rating) → RewardMapper
   → UserState update (history, dislikes, skips, genre EMA; per user, instant)
   → Policy update (bandit A, b; global, online)
   → next recommendation uses the new user embedding + new θ
```

- **Event schema** (`feedback/events.py`): user, item, type, timestamp, request_id, position, value,
  context. Events are immutable. Rewards are **derived** from events, so you can change the reward
  definition without losing data.
- **Reward mapping:** click = 1, like = 1, skip = 0, and rating adds 0.5·(r−3)/2.
- **User state** (`memory/user_state.py`):
  - A click or a rating ≥ 4 adds to the history, which changes the tower embedding.
  - A rating ≤ 2 goes into dislikes, and those items are blocked.
  - Two skips block an item, which stops the same item being recommended forever.
  - Three impressions without a click count as fatigue, and the item is blocked.
- **Why this differs from static recommendation.** The data distribution now depends on the model. A
  static model's mistakes stay fixed. A feedback-driven model can correct them (through exploration)
  or amplify them (popularity feedback loops).
- **Delayed feedback.** A rating can arrive days later. Options: attribute it to the request_id and
  update when it arrives; for conversions, use a wait window or a delayed-feedback model. Our
  simulator gives feedback immediately (a stated limitation).
- **Noisy feedback.** Accidental clicks, and clicks driven by clickbait rather than satisfaction. E6
  flips labels with probability p and measures the effect.

### Quiz 7
1. Walk one click event through every function it touches in the repo.
2. Why store events and derive state, instead of just storing state?
3. What does the "no adaptation" arm of E5 recommend in session 10? Why?

<details><summary>Answers</summary>

1. `Simulator.respond` → `feedback_to_events` → `MemoryStore.log_events` → `RewardMapper.reward` →
   `UserState.apply` (history append, genre EMA) → `MemoryStore.save_state` → `policy.update(x, r)`
   (Sherman–Morrison). On the next request, `BanditEnv.context` reads the new history, and
   `TwoTower.embed_history` computes the new z_u.
2. So you can replay: fix bugs, change the reward, rebuild state (`rebuild_state`), and audit. The
   state is a cache of the log.
3. The same popularity slate every session. It never learns the user's history, so the user's tower
   embedding is empty and the retriever falls back to popular items.
</details>

---

## 8. LLMs in recommendation (Phase 8)

**What LLMs are good at here**
- Turning messy language into structured constraints ("nothing too violent, 90s, like Heat").
- World knowledge about items: plot, tone, cast.
- Writing explanations.
- Orchestrating tools.

**What they're bad at, or cost**
- Ranking thousands of items. The context doesn't fit, it's slow and expensive, and it's
  inconsistent between calls.
- Personal taste learned from behaviour. The embeddings already do that better.
- Hallucination: recommending items that don't exist or aren't available.
- Latency of seconds per call against a feed budget of about 100 ms.
- Cost per call multiplied by requests per day.
- Non-determinism.
- Leakage on public datasets: the LLM already knows MovieLens movies and their later popularity.

**So in AgentRec:**
- There's **no LLM on the feed path.**
- In request mode, the LLM *plans and calls tools*, and every item it may output must come from
  `retrieve_candidates` in the same session. This grounding is enforced in code.
- Hard constraints from memory are applied in code, not trusted to the prompt.
- Tool arguments are validated against a JSON schema, and errors go back to the model as tool
  results.
- The prompt is `SYSTEM_PROMPT` in `agents/agent.py`. The context is the user request plus truncated
  tool outputs (`truncate`, 2,000 characters).

**Structured outputs / function calling.** The model returns
`{"name": "retrieve_candidates", "arguments": {...}}`. Your code executes it. The model never touches
the database.

**Evaluating the LLM component.**
- Constraint satisfaction against template ground truth, as in E8.
- Grounding-violation rate *before* the guardrail.
- Fill rate, fallback rate, tool calls per request, latency, and tokens.
- For explanations: faithfulness, meaning whether each claim is supported by tool outputs. That
  needs human or LLM-judge evaluation.

E8 runs with a rule-based planner here. `--llm` runs the same eval with a real model.

### Quiz 8
1. Give three reasons not to let the LLM rank the whole catalogue.
2. How exactly does the system *guarantee* that outputs are grounded? What does it do on violation?
3. Why is running the LLM on MovieLens titles a leakage risk for offline evaluation?

<details><summary>Answers</summary>

1. Context length (3,883 titles, or 10M in production); latency and cost per request; inconsistency
   and position bias of the LLM inside long lists; no access to behavioural signals; and
   hallucination.
2. `RecTools.recommend` rejects any id that isn't in `Session.retrieved`. It counts the violation and
   returns an error to the LLM, which can retry within the step budget. If it never succeeds, the
   agent falls back to the deterministic pipeline.
3. The model was pretrained on text written after the split, including reviews and "best of" lists.
   It knows which movies became popular, so part of any gain is memorised world knowledge rather than
   personalisation.
</details>

---

## 9. Agents (Phase 9)

**Definitions (be precise in interviews)**
- **LLM:** text in, text out. One call.
- **Workflow:** a *fixed* sequence of steps, possibly including LLM calls. The code decides the
  control flow.
- **Agent:** an LLM decides the **control flow at run time**. It chooses which tool to call next based
  on intermediate results, inside a loop, until it decides it is done.
- **Tool:** a function with a schema that the model may request.
- **State:** everything carried across steps (the session: retrieved ids, last candidates, and so
  on).
- **Memory:** state carried across sessions (UserState, SQLite).
- **Planning:** deciding a sequence of steps. **Replanning:** changing it after seeing results (for
  example, relaxing filters when too few candidates match).
- **Reflection:** the model critiques its own output before finishing. We don't implement it; the
  guardrail error message is a primitive form.
- **Guardrails:** step budget, schema validation, grounding check, code-enforced hard filters,
  deterministic fallback, and refusing to act on another user.
- **Agent evaluation:** task success (constraints met, filled), safety (violations caught),
  efficiency (steps, tool calls, tokens, latency), and robustness (injected failures).

**What makes AgentRec agentic, honestly stated.** Request mode runs a bounded loop in which the
planner chooses tool calls based on the request and on tool results. The number of steps varies:
retrieval is repeated with relaxed constraints when too few items match; `search_items` is called
only if a title is mentioned; `save_preference` only if a lasting dislike is stated. The *feed mode
is not agentic*, and shouldn't be.

**Honest caveat.** Our offline planner is rule-based, so its "decisions" are hand-coded rules. That
makes it a workflow expressed through the agent protocol. The agentic claim is fully true only when
an LLM drives the loop (`--llm`). The value an LLM adds is understanding requests that the regex
parser can't parse. Test that yourself with Ollama and report what you find.

**When an agent is unnecessary.** When the steps are always the same (the feed), when latency
matters in milliseconds, or when requests are structured (filters in a UI). A deterministic pipeline
is cheaper, faster, testable and predictable. Use an agent only when the input is open-ended and the
path can't be enumerated.

### Quiz 9
1. Is our rule-based planner an agent? Defend both answers.
2. List every guardrail in `agents/`, and say which failure each one prevents.
3. An interviewer says "this is just a pipeline with extra steps". Respond.

<details><summary>Answers</summary>

1. No: its control flow is fixed code, so it's a workflow. Yes, in a structural sense: it runs inside
   an agent loop, the path varies with the data (relaxation), and the planner is swappable for an
   LLM. The precise answer: *the architecture is agentic; the offline planner is a deterministic
   stand-in.*
2.
   - `max_steps`: prevents infinite loops and runaway cost.
   - `validate_args`: prevents malformed calls and invented genres.
   - The grounding check in `recommend`: prevents hallucinated or unavailable items.
   - Memory excludes applied inside `retrieve_candidates`: prevent violating stated preferences.
   - Blocked and seen items excluded: prevent re-recommending.
   - `_check_user`: prevents cross-user actions.
   - `truncate`: prevents context overflow.
   - One nudge, then fallback: prevents returning nothing.
   - The fallback pipeline: ensures there's always a valid answer.
3. "For the feed, yes, and that's deliberate. Request mode handles open-ended language, where the
   sequence of retrievals depends on what's found, for example relaxing constraints, or looking up a
   referenced title first. E8 shows the fixed single-pass pipeline under-fills tight requests and
   forgets stated preferences. The remaining question is whether an LLM planner beats the rule-based
   one on messy language, which I test with `--llm`."
</details>

---

## 10. Memory (Phase 10)

| kind | what it is | in AgentRec |
|---|---|---|
| conversation memory | messages in the current session | `messages` list in `RecAgent.run` (not persisted) |
| user profile | durable, structured facts about the user | `UserState.stated` (e.g. excluded genres) |
| episodic memory | "what happened when" | the `events` table |
| semantic memory | general facts and knowledge | item metadata; the LLM's world knowledge |
| interaction history | ordered user actions | `UserState.history` + the fit-period history |
| vector database | similarity search over embeddings / unstructured text | **not used**; item ANN is in `retrieval/` |
| feature store | low-latency features for serving, consistent with training | `FeatureBuilder` (in-process); in production, Redis, Feast, etc. |
| recommendation state | model state that changes online | bandit A⁻¹, b; the user embedding computed from history |

**The engineering trade-off.** The access pattern is "get everything for user u" and "append an
event". That's a keyed lookup, and SQLite does it perfectly. A vector DB would add a service, a
consistency problem, and cost, with no query that needs it. It would become justified if we stored,
say, free-text conversation snippets and needed "find past requests similar to this one".

### Quiz 10
1. Where would you store "user said they hate horror", and why not in the prompt?
2. When would you add a vector database to AgentRec?

<details><summary>Answers</summary>

1. In the structured user state (`stated.exclude_genres`), enforced in the retrieval code. A prompt
   instruction can be ignored, forgotten, or dropped from context. Code can't.
2. When there's unstructured memory to search by meaning: past conversations, reviews the user wrote,
   long item descriptions for semantic search. Or when item ANN outgrows in-process memory. Even
   then, a library such as FAISS may be enough before you need a separate database.
</details>

---

## 11. Putting it together: "Design an agentic recommendation system"

Say this order on a whiteboard:
1. **Clarify.** Feed or conversational? Scale (users, items, QPS)? Latency budget? Which signals
   exist? What are the objectives (engagement, diversity, freshness, safety)?
2. **Data.** Event logging schema, a temporal training pipeline, and a feature store.
3. **Retrieval.** Several sources (two-tower ANN, trending, item-to-item) merged to N ≈ 1,000.
4. **Ranking.** GBDT or deep ranker with rich features. Train on later windows; calibrate.
5. **Exploration.** A contextual bandit over the top of the list, with a prior from the ranker (and a λ large enough to make it matter), with
   position debiasing.
6. **Feedback.** Event stream → user state (real-time) + model updates (online bandit, periodic
   retrain).
7. **Request mode (agent).** An LLM planner with tools over the same retrieval and ranking; memory
   for stated preferences; guardrails (grounding, schemas, budgets, fallback).
8. **Evaluation.** Offline full-ranking metrics on a time split; simulators or off-policy estimation
   for the bandit; agent success, safety and cost metrics; then online A/B testing.
9. **Serving and monitoring.** Latency per stage; drift in feature, score and CTR distributions;
   coverage and popularity metrics; guardrail-violation rates; LLM cost.
10. **Scale.** Shard the ANN index; cache user embeddings; batch the ranker on GPU; call the LLM only
    in request mode and cache its outputs.

Reading list (real, stable sources)
- Rendle et al., *BPR: Bayesian Personalized Ranking from Implicit Feedback*, UAI 2009.
- Koren, Bell, Volinsky, *Matrix Factorization Techniques for Recommender Systems*, IEEE Computer 2009.
- Covington, Adams, Sargin, *Deep Neural Networks for YouTube Recommendations*, RecSys 2016.
  (Two stages: candidates + ranking.)
- Yi et al., *Sampling-Bias-Corrected Neural Modeling for Large Corpus Item Recommendations*,
  RecSys 2019. (logQ correction.)
- Li, Chu, Langford, Schapire, *A Contextual-Bandit Approach to Personalized News Article
  Recommendation*, WWW 2010. (LinUCB.)
- Li, Chu, Langford, Wang, *Unbiased Offline Evaluation of Contextual-bandit-based News Article
  Recommendation Algorithms*, WSDM 2011. (Replay.)
- Agrawal & Goyal, *Thompson Sampling for Contextual Bandits with Linear Payoffs*, ICML 2013.
- Auer, Cesa-Bianchi, Fischer, *Finite-time Analysis of the Multiarmed Bandit Problem*, MLJ 2002.
  (UCB1.)
- Krichene & Rendle, *On Sampled Metrics for Item Recommendation*, KDD 2020.
- Joachims, Swaminathan, Schnabel, *Unbiased Learning-to-Rank with Biased Feedback*, WSDM 2017.
  (Position bias, IPS.)
- Lattimore & Szepesvári, *Bandit Algorithms* (book, free online). Chapters 1–8 and 19–20.
- Yao et al., *ReAct: Synergizing Reasoning and Acting in Language Models*, ICLR 2023. (The agent
  loop pattern.)
- Anthropic, *Building effective agents* (engineering blog, Dec 2024). Covers workflows vs agents.
