# INTERVIEW_PREP.md

How to use this file:
1. Cover the answers, say your answer **out loud**, then open the `<details>` block.
2. The hidden text isn't a script to memorise. It lists **what a strong answer must contain**, plus
   the follow-up an interviewer will ask next. If your answer missed a point, work out *why* the
   point is true before moving on.
3. Log every miss in `INTERVIEW_WEAKNESSES.md`, including the question, your answer, the gap, and
   the exercise you'll do about it.
4. Use numbers from **your own** `results/` when answering. Never quote numbers you haven't
   reproduced.

The levels: L1 concepts · L2 implementation · L3 maths · L4 system design · L5 production ·
L6 failure cases · L7 research · L8 "it's broken, debug it". A code-defence drill is at the end.

---

## L1: concepts

**1. Why retrieval before ranking?**
<details><summary>must contain</summary>

- Cost: ranking every item costs |I| × ranker cost per request. Put numbers on it (E2's ns/item,
  scaled to 10M).
- Retrieval uses a factorised score, which can be searched with ANN in sub-linear time.
- The two stages have different objectives: retrieval optimises recall, ranking optimises precision
  at the top.
- Follow-up to expect: "what's lost?" → the ranker can't recover an item that retrieval dropped. Show
  Recall@N from E2 and the candidate-size ablation from E3.
</details>

**2. Explicit vs implicit feedback. Which does your project use, and how?**
<details><summary>must contain</summary>

Ratings are converted to implicit positives (≥ 4); ≤ 3 means seen but not liked; items that were
seen are masked at evaluation. The simulator also produces clicks, skips and ratings. Implicit
feedback has no true negatives and is biased by exposure and position.
</details>

**3. What is cold start, and what does AgentRec do about it?**
<details><summary>must contain</summary>

- New users: a popularity fallback (`Recommender.score`, `CandidateRetriever` with user_vec = None).
  After clicks, the history-based tower gives a personal embedding with no retraining (E5).
- New items: genre features in the item tower and the content model. CF can't score them.
- Quote the cold slice from E1.
</details>

**4. Exploration vs exploitation. Give a recommender example.**

**5. Offline vs online evaluation. Why can offline evaluation be misleading?**
<details><summary>must contain</summary>

- Logs only contain feedback for items the old policy showed (selection bias), and positions bias
  the clicks.
- Popularity dominates, so offline metrics can reward popularity bias.
- Time leakage if the split is random.
- Sampled metrics distort the comparison.
- The metric (NDCG on held-out ratings) isn't the business goal (long-term satisfaction).
- Offline gains often don't transfer, which is why A/B tests exist.
</details>

**6. What makes the system agentic? Why not just build a deterministic pipeline?**
<details><summary>must contain</summary>

- Precise definitions of workflow and agent (control flow decided by the model at run time).
- Feed mode is deliberately **not** agentic.
- Request mode: tools, a bounded loop, a data-dependent number of steps (relaxation, conditional
  search or save), memory, and guardrails.
- **Honesty:** the offline planner is rule-based. The LLM planner is optional and was evaluated with
  `--llm` (only if you actually ran it).
- When a pipeline is better: fixed steps, tight latency, structured input.
</details>

**7. What exactly is the reward?**
<details><summary>must contain</summary>

For the bandit: a click (0/1) on each shown item. In the feedback loop, RewardMapper gives
click = 1, like = 1, skip = 0, and a rating adds 0.5·(r−3)/2. Why a skip isn't negative: it's
already 0 relative to a click, and a harsher penalty would push the policy toward "safe", popular
items. The reward definition is a product decision: clicks ≠ satisfaction, and there's clickbait
risk. That's why events are stored and rewards derived, so the definition can change.
</details>

---

## L2: implementation

**8. Walk me through `TwoTower.loss_and_grads`.**
<details><summary>must contain</summary>

- Forward: the masked mean of history embeddings → residual MLP → z. The item vector v is E[i] plus
  a genre projection. Both are L2-normalised; the logits are the cosine over τ minus log q; duplicate
  positives are masked; then softmax cross-entropy.
- Backward: (P − Y)/B → the normalisation backward → MLP → scatter-add into H and E with `np.add.at`
  (duplicates!).
- Say how it was verified: the finite-difference test.
</details>

**9. Why `np.add.at` rather than `P[u] += grad`?**
<details><summary>must contain</summary>

With repeated indices in a batch, fancy-index `+=` applies only one of the updates, which is a silent
bug. `np.add.at` accumulates all of them.
</details>

**10. How is leakage prevented, concretely?**
<details><summary>must contain</summary>

- The global time split.
- Tuning on val, refitting on train+val.
- Two-tower history is strictly before the target (tested).
- Ranking features come from the fit period only.
- The ranker is trained on a later window than stage 1.
- The simulator's truth is never given to the models.
</details>

**11. How do you guarantee recommendations are grounded in retrieved candidates? How do you stop
the LLM recommending unavailable items?**
<details><summary>must contain</summary>

- `Session.retrieved` is the grounding set, filled only by `retrieve_candidates`.
- `recommend` rejects anything outside it and returns the error to the LLM; the step budget and the
  fallback follow.
- Retrieval itself excludes seen, blocked and unavailable items (hard filters in code).
- E8's halluc system: N violations injected, N caught, 100% of final outputs grounded.
- The limit: this guarantees *membership*, not that the explanation text is true.
</details>

**12. Why SQLite and not a vector DB for memory?**

**13. How does the bandit warm-start from the ranker, and when does that warm start fail?** Cover θ₀, and λ as prior strength. At t = 0, LinUCB's bonus α‖x‖/√λ can dwarf the prior term, so the first slates aren't the ranker's (EXPERIMENTS E4). A larger λ mitigates it (1/√λ) but doesn't remove it: an independent check found 9 of 100 users matched at λ = 1 and 30 of 100 at λ = 100.

---

## L3: maths

**14. Derive the BPR gradient for p_u.**
<details><summary>must contain</summary>

L = −ln σ(x) with x = p·(q_i − q_j). dL/dx = −σ(−x). Therefore
dL/dp = −σ(−x)(q_i − q_j) + reg·p. Interpretation: the step is large when the pair is mis-ordered.
</details>

**15. Derive the UCB1 bonus intuition from Hoeffding.**
<details><summary>must contain</summary>

P(μ > μ̂ + ε) ≤ exp(−2nε²). Set that to t⁻⁴ (or 1/t) and solve for ε: ε = √(2 ln t / n) (the
constant depends on the choice). So the true mean is below the UCB with high probability, and an arm
is played only while it could plausibly be the best.
</details>

**16. Why is Beta the posterior for Bernoulli rewards?**
<details><summary>must contain</summary>

The likelihood is θ^s(1−θ)^f and the prior is θ^(α−1)(1−θ)^(β−1). Their product has the same form,
so the posterior is Beta(α+s, β+f).
</details>

**17. Show that Sherman–Morrison gives (A + xxᵀ)⁻¹.** Multiply it out. Explain why it's O(d²)
instead of O(d³).

**18. What is xᵀA⁻¹x in LinUCB, statistically?**
<details><summary>must contain</summary>

In the Bayesian view (Gaussian prior N(θ₀, σ²/λ·I), Gaussian noise σ²), the posterior variance of θᵀx is σ² xᵀA⁻¹x. The frequentist variance of the ridge estimate is σ² xᵀA⁻¹XᵀXA⁻¹x ≤ σ² xᵀA⁻¹x. Either way, √ is (at most) the
standard deviation of the predicted reward. α sets how many standard deviations of optimism to add.
</details>

**19. Compute NDCG@5 for hits at ranks 1 and 4 with |R| = 3.**
(DCG = 1 + 1/log₂5 = 1.431. IDCG = 1 + 0.631 + 0.5 = 2.131. NDCG = 1.4307 / 2.1309 = 0.671.)

**20. Why the logQ correction? Derive the direction of the bias.**
<details><summary>must contain</summary>

Sampled softmax with a proposal q gives biased gradients unless the logits are corrected by −log q.
Popular items are over-sampled as negatives, so without the correction the model is pushed to score
them lower than it should.
</details>

---

## L4: system design

**21. Scale this to 100M users and 10M items.**
<details><summary>must contain</summary>

- Offline: train the two-tower on a GPU cluster with in-batch negatives plus mixed negatives. Export
  item embeddings on a schedule and build a sharded ANN index (HNSW or IVF-PQ).
- Online: compute the user embedding from recent events (feature store / streaming) and cache it.
  Use several retrieval sources merged to about 1k. The ranker is GBDT or a DNN on GPU with batching.
  The bandit scores the top ~50 (O(d²) per item, cheap). Put a filter and business-rules layer last.
- The event stream (Kafka) feeds both the user state (real-time) and the training data (batch).
- The LLM runs only in request mode: rate-limited, cached, and with a fallback.
- Budget: roughly 10 ms embedding, 10–20 ms ANN, 30–50 ms ranking, 1 ms bandit.
</details>

**22. Where is the bottleneck, and how would you reduce latency?**
<details><summary>must contain</summary>

- Use your latency table (`results/*/latency.md`) and name the biggest stage. In our run that's the
  **ranker** (sklearn GBDT `predict_proba` on 200 rows, about 1.7 ms), then features and retrieval
  (about 0.4–0.5 ms each).
- Fixes: vectorise and batch, precompute item features, cache user features, use a smaller N, run
  ANN instead of exact search at scale, compile the ranker, and do early exits.
- For the agent: the LLM calls dominate, so cut steps (a better plan), use a smaller model, cache,
  and parallelise independent tool calls.
</details>

**23. How would you deploy it?** Cover: containerised services (retrieval, ranking, agent), model
registry, shadow mode → canary → A/B, feature parity between training and serving, and rollback.

**24. How would you monitor it? How would you detect recommendation drift?**
<details><summary>must contain</summary>

- Data drift: feature distributions (PSI/KS) and embedding norms.
- Output drift: score distributions, coverage, popularity percentile of recommendations, genre mix.
- Outcomes: CTR, skip rate, rating distribution by cohort.
- Bandit: exploration rate, θ drift, regret proxies.
- Agent: fallback rate, grounding violations caught, schema errors, tool calls per request,
  latency, tokens.
- Alerts on shifts relative to trailing windows.
</details>

**25. Why contextual bandits instead of supervised learning on logs?** (See LEARNING_NOTES §6.8.
Mention that you can combine them: supervised ranker + bandit exploration on top.)

---

## L5: production engineering

**26. How do you handle delayed feedback?**
<details><summary>must contain</summary>

- Join by request_id when the feedback arrives, and update the policy then.
- Use an attribution window. For conversions, delayed-feedback models, or treat "not yet" as unknown
  rather than negative.
- Our simulator is immediate: say so.
</details>

**27. What happens if users click because of position bias?** Cover the PBM, the naive vs
position-feature vs oracle result from E4b, and IPS as an alternative.

**28. How do you avoid popularity bias?**
<details><summary>must contain</summary>

- Measure it: `mean_pop_percentile@10` and tail recall from E1.
- Mitigate: exploration, logQ correction, re-ranking for diversity or calibration, exposure
  constraints, and a long-tail retrieval source.
- The trade-off with accuracy.
</details>

**29. How do you prevent feedback loops?** Exploration, randomised traffic slices (which also give
logs for replay evaluation), propensity logging, diversity constraints, and monitoring coverage over
time.

**30. How do you evaluate the LLM component?** Refer to LEARNING_NOTES §8 and E8. Add: golden
request sets, LLM-as-judge for explanation faithfulness (validated against human labels), cost and
latency, and regression tests on every prompt change.

**31. What happens when a new user enters?** The code path, step by step, plus E5 numbers.

**32. What happens when the bandit receives biased or noisy feedback?** Cover E6 (label flips) and
E4b (position). With biased feedback, the estimates converge to the *biased* reward. Exploration
doesn't fix bias; debiasing does.

---

## L6: failure cases

**33. The ranker beats retrieval order on validation but not on test.** (See LEARNING_NOTES Quiz 5.3.)

**34. The agent returns 3 items when 5 were asked.** Candidates: filters too tight and relaxation
disabled or exhausted, `blocked_items` too aggressive, or `top_k` not passed. How you'd check:
inspect the trajectory's `count` fields.

**35. The LLM keeps calling `retrieve_candidates` with `include_genres: ["Sci Fi"]`.** Schema
validation rejects it (not in the enum); the error lists the allowed values; the model retries.
Measure it with `schema_errors`. Fixes: put the enum in the prompt, or map synonyms in the tool.

**36. After a deploy, CTR is up 5% but ratings are down.** Clickbait or a proxy-reward mismatch.
Look at the reward definition, rating-weighted rewards, and guardrail metrics.

**37. Cold-start users get the same 10 items forever.** No feedback is being applied (a user-state
bug), or impression fatigue isn't working. It's the E5 "no adaptation" curve. Check the event logging
and `save_state`.

---

## L7: research-level

**38. How would you evaluate the bandit offline with real logs?** IPS, SNIPS, doubly robust; logging
propensities are needed; replay on randomised traffic; variance problems for slates (pseudo-inverse
estimators).

**39. Slate bandits: why is K independent picks wrong?** Items in a slate interact (substitutes,
diversity). Cascade and PBM models; combinatorial bandits; the slate-Q idea.

**40. Would a generative / sequence model (SASRec, an LLM-as-recommender) beat the two-tower here?**
The trade-offs: sequence order and capacity vs latency and ANN-compatibility, and data size (ML-1M
is small). What experiment you'd run.

**41. Is the MovieLens simulator's "truth" valid?** It's a BPR model fit on all data, so the bandit
is being evaluated against a model's opinion. Consequences: results favour policies whose features
align with MF structure. Mitigations: several truth models, and the fully observed KuaiRec.

---

## L8: "your system is broken, debug it"

For each scenario, state: hypotheses → the cheapest check → the fix.

**B1. NDCG on test is 3× higher than on val, and higher than any paper reports.**
<details><summary>approach</summary>

Suspect leakage first. Check:
- the split boundaries (max train ts < min test ts);
- whether the seen-item mask used the right period;
- whether test items appear in the training history;
- whether the sampled-metrics flag is on;
- duplicate users between the fit and eval sets with future data.

Run `test_temporal_split_has_no_time_overlap`.
</details>

**B2. The two-tower loss goes down, but recall is at the popularity level.**
<details><summary>approach</summary>

- The embeddings may have collapsed: check the variance of z across users and of V across items.
- τ may be too high.
- logQ may be subtracted with the wrong sign.
- The history window may be empty (padding bug: `mask.sum() == 0` everywhere).
- The user embeddings used at inference may be built from the wrong period's history.
- Run the gradient check.
</details>

**B3. LinUCB regret is worse than the frozen ranker.**
<details><summary>approach</summary>

- α is too large, so it over-explores: check the exploration rate.
- Feature scales differ, so the widths are dominated by one feature.
- λ is too small, so θ₀ is forgotten instantly and noisy early updates dominate.
- The naive position update is punishing low positions.
- Rewards are misaligned with the simulator's click probabilities.
- Compare against E4c.
</details>

**B4. The agent's p95 latency is 40 s.** Count LLM calls per request in the trajectory. Look for
loops: the same failing tool call repeated, and the step budget too large. Check context size, since
tool outputs may not be truncated. Check for timeouts without retries or backoff.

**B5. A user who said "no horror" got a horror movie.** Was the preference saved? (`stored_preferences`
in the profile.) Was it enforced in `retrieve_candidates` (code) or only in the prompt? Did the
fallback path bypass the filter? Does the item have a missing genre tag (metadata quality)?

**B6. Recommendations are identical for every user.**
<details><summary>approach</summary>

- The cold fallback is being triggered for everyone (`has_history` all False: check the fit period).
- User embeddings are all zero.
- The ranker's weight is dominated by popularity.
- The seen mask is broken.
- Check coverage@10 in E1.
</details>

---

## Code-defence drill

Pick a file at random (`ls src/agentrec/*/*.py | shuf -n1`). Without looking at the docs, answer:
1. Why does this module exist? What would break without it?
2. Inputs and outputs, with types and shapes.
3. What assumptions does it make? (Sorted inputs? Contiguous IDs? Normalised vectors?)
4. Computational complexity of its main function.
5. What happens with malformed input? Point to the validation line, or admit there isn't one.
6. One alternative implementation and its trade-off.
7. One bug that could plausibly exist in it. Then go and look for it.

Starter prompts:
- `retrieval/index.py`: why does `ExactIndex.search` set ids to −1 when the score is −inf?
  (Answer: when fewer than k items are allowed, argpartition would otherwise return **excluded**
  items. This bug existed during development and was caught by an agent test. Tell that story.)
- `bandits/linear.py`: why is `LinTS` symmetrising A⁻¹ before the Cholesky factorisation?
- `agents/tools.py`: what happens if the LLM passes `n = 100000`?
- `feedback/loop.py`: in what order must `log_events`, `state.apply` and `policy.update` happen, and
  why?
- `evaluation/evaluator.py`: why does the mask use *all* seen items but the targets only positives?
- `models/two_tower.py::_batch`: explain the index arithmetic line by line.
- `data/dataset.py::build_dataset`: why are IDs mapped over the full catalogue rather than over
  training items?
